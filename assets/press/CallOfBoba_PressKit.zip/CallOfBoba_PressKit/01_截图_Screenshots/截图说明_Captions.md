# 截图说明 / Screenshot Captions

共 16 张，均为《啵啵鸡物语》Ver.0.0.4.0 实机画面，没有界面（UI）和对白文字，只有场景招牌上的美术字。每张都有两个版本：`1280x720/`（游戏原生 320×180 的整 4 倍，像素原样）和 `1920x1080/`（整数倍放大后再缩小，像素边缘清晰）。`总览_Overview.jpg` 按编号从左到右、从上到下排列。

16 in-game screenshots from Call of Boba Ver.0.0.4.0, with no UI or dialogue text (only in-world signage). Each comes in two sizes: `1280x720/` (exactly 4× the native 320×180, pixels untouched) and `1920x1080/` (integer-scaled and then reduced, so pixel edges stay crisp). `总览_Overview.jpg` shows them in number order, left to right and top to bottom.

| # | 文件名（不含尺寸后缀） | 中文说明 | English caption |
|---|---|---|---|
| 01 | `CallOfBoba_01_spring_station_arrival` | 开场：春天，啵啵在木薯小站下车回到家乡，兔子造型的黄色车子停在站台边，樱花飘落 | Opening: Bobo arrives home at Tapioca station on a spring day, with the bunny-shaped yellow shuttle at the platform |
| 02 | `CallOfBoba_02_spring_lake_pier` | 春·湖畔栈道：樱花树与睡莲，啵啵站在钓鱼栈道上 | Spring at the lake: cherry trees, lily pads, and Bobo on the fishing pier |
| 03 | `CallOfBoba_03_spring_tapioca_plaza` | 春·木薯广场：喷泉雕像、长椅与小吃车 | Spring in Tapioca Plaza: fountain statue, benches, and a snack cart |
| 04 | `CallOfBoba_04_spring_milk_tea_shop_exterior` | 避雨巷奶茶店门口（春） | Outside the Sheltered Lane Milk Tea Shop in spring |
| 05 | `CallOfBoba_05_residents_boba_break` | 抹茶商店街：居民们坐在避雨巷奶茶店门口喝奶茶 | Matcha Market: residents sipping boba outside the Sheltered Lane Milk Tea Shop |
| 06 | `CallOfBoba_06_flower_daily_interior` | 每日鲜花店：店里摆满了盆栽和鲜花 | Inside Flower Daily, packed with potted plants and flowers |
| 07 | `CallOfBoba_07_rnd_room` | 研发室：研磨机与合成锅，把收成加工成小料 | The R&D Room, where the grinder and mixing pot turn harvests into drink ingredients |
| 08 | `CallOfBoba_08_summer_farm` | 夏·农场：一畦畦作物，洒水器正在浇水 | Summer farm: rows of crops while the sprinklers do the watering |
| 09 | `CallOfBoba_09_summer_cloud_resort` | 夏·云朵居：遮阳伞、野餐垫和南瓜 | Summer at Cloud Resort: a parasol, a picnic blanket, and pumpkins |
| 10 | `CallOfBoba_10_summer_rain_pier` | 夏日雨天的湖畔栈道：睡莲、香蒲与瀑布 | A summer rain over the lake pier: lily pads, cattails, and the waterfall |
| 11 | `CallOfBoba_11_autumn_waterfall_bridge` | 秋·居民区瀑布：木桥、落叶与串串餐车 | Autumn by the Neighborhood waterfall: wooden bridge, falling leaves, and a skewer food truck |
| 12 | `CallOfBoba_12_autumn_lake` | 秋·湖畔：金黄的树和飘落的叶子 | Autumn at the lake: golden trees and drifting leaves |
| 13 | `CallOfBoba_13_winter_milk_tea_shop_snowman` | 冬·奶茶店门口的雪人 | Winter: a snowman outside the milk tea shop |
| 14 | `CallOfBoba_14_winter_tapioca_plaza` | 冬·木薯广场：雪落在喷泉雕像上 | Winter in Tapioca Plaza: snow on the fountain statue |
| 15 | `CallOfBoba_15_night_lucky_duck_arcade` | 夜晚：亮灯的幸运鸭街机店 | Night: the Lucky Duck Arcade lit up |
| 16 | `CallOfBoba_16_dreamland_entrance` | 梦境入口：每晚入梦从这里出发（目前开放的是第一大关） | The Dreamland entrance, where each night's run begins (Level 1 is the one currently open) |

## 补充：奶茶店营业（含少量界面）/ Supplement: the shop in action (with some UI)

这两张来自营业玩法，画面上带有少量游戏界面（金币数或冰淇淋卡），所以没有放进上面的无 UI 套图。画面上没有文字，中英文通用。

These two come from the shop gameplay and show a little game UI (the coin counter, or the ice cream card), so they're kept out of the no-UI set above. They have no on-screen text and work for any language.

| # | 文件名（不含尺寸后缀） | 中文说明 | English caption |
|---|---|---|---|
| S1 | `补充_奶茶店营业_含界面_ShopWithUI/…/CallOfBoba_S1_shop_busy_service` | 奶茶店营业中：座位几乎坐满，顾客头顶是订单气泡（右上角是金币数界面） | The milk tea shop in full swing: nearly every seat taken, with order bubbles over the customers (coin counter top right) |
| S2 | `补充_奶茶店营业_含界面_ShopWithUI/…/CallOfBoba_S2_shop_ice_cream_card` | 冰淇淋机：按对方向键序列后，翻出一张甜筒卡 | The ice cream machine: get the arrow sequence right and a cone card flips up |

图片来源署名（建议）：《啵啵鸡物语》Call of Boba / 面包柿工作室 Tomatoast
Suggested credit: Call of Boba / Tomatoast
